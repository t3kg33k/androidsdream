import QtQuick
import org.kde.plasma.configuration

ConfigModel {
    ConfigCategory {
        name: i18n("Drives")
        icon: "drive-harddisk"
        source: "configDrives.qml"
    }
    ConfigCategory {
        name: i18n("Colors")
        icon: "preferences-desktop-color"
        source: "configColors.qml"
    }
}
