import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import org.kde.kirigami as Kirigami
import org.kde.kcmutils as KCM
import org.kde.kquickcontrols as KQC

KCM.SimpleKCM {
    property alias cfg_useCustomColors: useCustom.checked
    property alias cfg_barColor: barBtn.color
    property alias cfg_warnColor: warnBtn.color
    property alias cfg_warnThreshold: warnSpin.value
    property alias cfg_textColor: textBtn.color
    property alias cfg_trackColor: trackBtn.color
    property alias cfg_backgroundColor: bgBtn.color

    property bool cfg_useCustomColorsDefault
    property color cfg_barColorDefault
    property color cfg_warnColorDefault
    property int cfg_warnThresholdDefault
    property color cfg_textColorDefault
    property color cfg_trackColorDefault
    property color cfg_backgroundColorDefault

    Kirigami.FormLayout {
        QQC2.CheckBox {
            id: useCustom
            Kirigami.FormData.label: i18n("Theme:")
            text: i18n("Use custom colors (otherwise follow the system theme)")
        }

        Item { Kirigami.FormData.isSection: true }

        KQC.ColorButton {
            id: bgBtn
            Kirigami.FormData.label: i18n("Background:")
            showAlphaChannel: true
            enabled: useCustom.checked
        }
        KQC.ColorButton {
            id: textBtn
            Kirigami.FormData.label: i18n("Text:")
            enabled: useCustom.checked
        }
        KQC.ColorButton {
            id: trackBtn
            Kirigami.FormData.label: i18n("Bar track:")
            enabled: useCustom.checked
        }
        KQC.ColorButton {
            id: barBtn
            Kirigami.FormData.label: i18n("Usage bar:")
            enabled: useCustom.checked
        }
        KQC.ColorButton {
            id: warnBtn
            Kirigami.FormData.label: i18n("Warning bar:")
            enabled: useCustom.checked
        }
        QQC2.SpinBox {
            id: warnSpin
            Kirigami.FormData.label: i18n("Warn at usage (%):")
            from: 1
            to: 100
            enabled: useCustom.checked
        }
    }
}
