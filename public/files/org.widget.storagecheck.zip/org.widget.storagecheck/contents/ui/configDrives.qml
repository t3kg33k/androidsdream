import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import QtQuick.Dialogs
import org.kde.kirigami as Kirigami
import org.kde.kcmutils as KCM

KCM.SimpleKCM {
    id: page

    property var cfg_drives
    property var cfg_drivesDefault
    property alias cfg_refreshSeconds: refresh.value
    property int cfg_refreshSecondsDefault

    property int browseIndex: -1

    ListModel { id: driveModel }

    function save() {
        const out = []
        for (let i = 0; i < driveModel.count; i++) {
            const d = driveModel.get(i)
            out.push(d.label + "|" + d.path)
        }
        cfg_drives = out
    }

    Component.onCompleted: {
        for (const s of (cfg_drives || [])) {
            const i = s.indexOf("|")
            driveModel.append({ label: s.slice(0, i), path: s.slice(i + 1) })
        }
    }

    FolderDialog {
        id: folderDialog
        onAccepted: {
            if (page.browseIndex < 0) return
            const p = decodeURIComponent(selectedFolder.toString().replace(/^file:\/\//, ""))
            driveModel.setProperty(page.browseIndex, "path", p)
            page.save()
        }
    }

    ColumnLayout {
        spacing: Kirigami.Units.largeSpacing

        RowLayout {
            QQC2.Label { text: i18n("Refresh every (seconds):") }
            QQC2.SpinBox { id: refresh; from: 5; to: 3600 }
        }

        Repeater {
            model: driveModel
            delegate: RowLayout {
                required property int index
                required property string label
                required property string path
                Layout.fillWidth: true

                QQC2.TextField {
                    text: label
                    placeholderText: i18n("Label")
                    Layout.preferredWidth: Kirigami.Units.gridUnit * 8
                    onEditingFinished: { driveModel.setProperty(index, "label", text); page.save() }
                }
                QQC2.TextField {
                    text: path
                    placeholderText: i18n("/mount/point")
                    Layout.fillWidth: true
                    onEditingFinished: { driveModel.setProperty(index, "path", text); page.save() }
                }
                QQC2.Button {
                    icon.name: "document-open-folder"
                    onClicked: { page.browseIndex = index; folderDialog.open() }
                }
                QQC2.Button {
                    icon.name: "list-remove"
                    onClicked: { driveModel.remove(index); page.save() }
                }
            }
        }

        QQC2.Button {
            text: i18n("Add drive")
            icon.name: "list-add"
            onClicked: { driveModel.append({ label: "", path: "/" }); page.save() }
        }
    }
}
