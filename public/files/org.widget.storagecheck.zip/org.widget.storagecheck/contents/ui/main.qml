import QtQuick
import QtQuick.Layouts
import org.kde.plasma.plasmoid
import org.kde.plasma.core as PlasmaCore
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.plasma5support as P5Support
import org.kde.kirigami as Kirigami

PlasmoidItem {
    id: root

    // results keyed by the shell command that produced them
    property var stats: ({})

    readonly property bool custom: Plasmoid.configuration.useCustomColors
    readonly property color cText: custom ? Plasmoid.configuration.textColor : Kirigami.Theme.textColor
    readonly property color cTrack: custom ? Plasmoid.configuration.trackColor : Kirigami.Theme.alternateBackgroundColor
    readonly property color cBar: custom ? Plasmoid.configuration.barColor : Kirigami.Theme.highlightColor
    readonly property color cWarn: custom ? Plasmoid.configuration.warnColor : Kirigami.Theme.negativeTextColor
    readonly property int warnAt: Plasmoid.configuration.warnThreshold

    Plasmoid.backgroundHints: custom ? PlasmaCore.Types.NoBackground
                                     : PlasmaCore.Types.DefaultBackground

    // "Label|/path" strings -> [{label, path, cmd}]
    readonly property var drives: (Plasmoid.configuration.drives || []).map(s => {
        const i = s.indexOf("|")
        const path = s.slice(i + 1)
        return { label: s.slice(0, i), path: path, cmd: cmdFor(path) }
    })

    function cmdFor(path) {
        const quoted = "'" + path.replace(/'/g, "'\\''") + "'"
        return "df -h --output=size,avail,pcent -- " + quoted + " 2>/dev/null | tail -n1"
    }

    P5Support.DataSource {
        engine: "executable"
        connectedSources: root.drives.map(d => d.cmd)
        interval: Math.max(5, Plasmoid.configuration.refreshSeconds) * 1000
        onNewData: (source, data) => {
            const p = (data["stdout"] || "").trim().split(/\s+/)
            const next = Object.assign({}, root.stats)
            next[source] = p.length === 3
                ? { size: p[0], avail: p[1], pct: parseInt(p[2]) }
                : null
            root.stats = next
        }
    }

    toolTipMainText: i18n("Storage Check")
    Plasmoid.icon: "drive-harddisk"

    fullRepresentation: Item {
        readonly property int pad: Kirigami.Units.largeSpacing
        Layout.minimumWidth: Kirigami.Units.gridUnit * 16
        Layout.minimumHeight: col.implicitHeight + 2 * pad

        Rectangle {
            anchors.fill: parent
            visible: root.custom
            radius: Kirigami.Units.cornerRadius
            color: Plasmoid.configuration.backgroundColor
        }

        ColumnLayout {
            id: col
            anchors.fill: parent
            anchors.margins: parent.pad
            spacing: Kirigami.Units.largeSpacing

            Repeater {
                model: root.drives
                delegate: ColumnLayout {
                    required property var modelData
                    readonly property var s: root.stats[modelData.cmd]
                    readonly property bool warn: s && s.pct >= root.warnAt
                    Layout.fillWidth: true
                    spacing: 2

                    RowLayout {
                        Layout.fillWidth: true
                        PlasmaComponents.Label {
                            text: modelData.label
                            color: root.cText
                            font.bold: true
                            Layout.fillWidth: true
                            elide: Text.ElideRight
                        }
                        PlasmaComponents.Label {
                            text: s ? i18n("%1 free · %2% used", s.avail, s.pct)
                                    : i18n("unavailable")
                            color: root.cText
                            opacity: 0.8
                        }
                    }

                    // custom bar so the colors are fully controllable
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: Kirigami.Units.gridUnit * 0.6
                        radius: height / 2
                        color: root.cTrack
                        Rectangle {
                            width: parent.width * (s ? Math.min(100, s.pct) / 100 : 0)
                            height: parent.height
                            radius: parent.radius
                            color: warn ? root.cWarn : root.cBar
                        }
                    }
                }
            }

            PlasmaComponents.Label {
                visible: root.drives.length === 0
                text: i18n("No drives configured. Right-click → Configure.")
                color: root.cText
                wrapMode: Text.WordWrap
                Layout.fillWidth: true
            }
        }
    }
}
